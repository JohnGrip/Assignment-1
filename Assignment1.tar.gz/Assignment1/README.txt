README.txt
C++ Assingnment 1
GRPJAM001
James Gripper

files:

Assignment1/README.txt
Assignmnet1/src/cmdline_parser.cpp
		cmpline_parser.h
		counter.h
		DataBase.cpp
		DataBase.h
		driver.cpp
		driver.h
		driver.o
		mkaefile
		StudentRecord.cpp
		StudentRecord.h
		tokenlib.cpp
		tokenlib.h
Assignment1/Debug/makefile
		  objects.mk
		  sources.mk
Assignment1/Debug/src/DataBase.d
		      DataBase.o
		      driver.d
		      driver.o
		      StudentRecord.d
		      StudentRecord.o
		      subdir.mk

Part 1:

A menu was implemented as instructed.
An infinte for loop would should the options to the user after each command.
The StudentRecord class contians all the attributes which which belong to a StudentRecord as speciied.
All of the code submitted in this assignment can be viewed in a text editor to check the validity of it as no output is produced as errors occured which I had no idea what they meant or how to fix them.
I completed as much code as I knew how however many of the ideas have never been explained to us and I did not have time to look them all up as I was unaware that the practical aspect of this course is actually selfstudy..

Part 2:

I have implemented some of the methods for the stubs which occur in the driver.cpp file and are situated in the DataBase.cpp file.

To make the project just type in make in the terminal and errors everywhere will occur.. yay. I don't know what these errors mean..

I should have started this prac sooner, so please be nice to me and give me some marks??






















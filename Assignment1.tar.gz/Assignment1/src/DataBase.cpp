/*
 * DataBase.cpp
 *
 *  Created on: 13 Mar 2014
 *      Author: grpjam001
 */

#include "DataBase.h"
#include "StudentRecord.h"

#include <stdlib.h>
#include <fstream>  // Needed for file stream objects
#include <iostream> // Needed for console stream objects
#include <sstream>  // Needed for string stream objects
#include <string>   // Needed for strings
#include <list>   // Needed for the vector container


	string students[20];
	//add student method
	/*void DataBase::addStudent(StudentRecord s)
	{
	}*/
	
	//delete student from database method
	void deleteStudent(void)
	{
		std::string ID;

		std::cout << "Enter student number of the student you wish to delete" << std::endl;//delete student with username given
		std::cin >> ID;

	}
	
	//prints the students the database 
	void readDatabase(void)
	{
		for(int i; i<20; i++)
		//prints the list of students
		std::cout << Students[i] << std::endl;
	}
	
	//saves the state of the database
	void saveDatabase(void)
	{
		std::cout << "Database has been saved" << std::endl;
	}

	//prints the data of the student the user wishes to see
	void displayData(void)
	{
		std::cout << "Which student would you like to view? (Enter student number)" << std::endl;
		// find student info in array and send it to cout.
	}

	//calculates the average of the student the user chooses
	void gradeStudent(void)
	{
		std::cout << "Which student would you like to grade? (Enter student number)" << std::endl;
		//calculate average
	}

	//returns all the students in the database
	void displayAllData(void)
	{
		for(int i; i<20; i++)
		//prints the list of students
		std::cout << Students[i] << std::endl;
		//print student array
	}

	//finds the student with the highest average mark
	void findWinner(void)
	{
		// display student with highest average
	}

	//quits the program
	void Quit(void)
	{
		exit(0);
	}

/*
 * driver.h
 *
 *  Created on: 13 Mar 2014
 *      Author: grpjam001
 */

#ifndef DRIVER_H_
#define DRIVER_H_

namespace GRPJAM001 {

class driver {
public:
	virtual ~driver();
	driver();
};

} /* namespace GRPJAM001 */
#endif /* DRIVER_H_ */

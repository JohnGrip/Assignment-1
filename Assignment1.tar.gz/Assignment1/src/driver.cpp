//============================================================================
// Name        : Assignment1.cpp
// Author      : James Gripper - GRPJAM001
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <fstream>  // Needed for file stream objects
#include <iostream> // Needed for console stream objects
#include <sstream>  // Needed for string stream objects
#include <string>   // Needed for strings
#include <string.h>
#include <vector>   // Needed for the vector container
#include "DataBase.h"
#include "StudentRecord.h"

namespace GRPJAM001
{
int main(void)
{
	DataBase d;
	int i;
	for (;;)
	{
		std::cout << "0: Add Student"  << std::endl;
		std::cout << "1: Delete Given Student" << std::endl;
		std::cout << "2: Read Database" << std::endl;
		std::cout << "3: Save Database" << std::endl;
		std::cout << "4: Display Given Student Data"  << std::endl;
		std::cout << "5: Grade Student" << std::endl;
		std::cout << "6: Display all Student Data" << std::endl;
		std::cout << "7: Find Winning Student" << std::endl;
		std::cout << "q: Quit" << std::endl;
		std::cout << "Enter a number (or q to quit) and press return..." << std::endl;
		std::cin >> i;
		if (i==0)
		{
			std::string first;
			std::string last;
			std::string num;
			std::string marks;
			std::cout << "Enter first name" << std::endl;
			std::cin >> first;
			std::cout << "Enter surname" << std::endl;
			std::cin >> last;
			std::cout << "Enter student number" << std::endl;
			std::cin >> num;
			std::cout << "Enter class record" << std::endl;
			std::cin >> marks;
			//d.addStudent(StudentRecord(first, last, num, marks));
		}
		else if (i==1)
		{
			void deleteStudent(void);
		}
		else if (i==2)
		{
			void readDatabase(void);
		}
		else if (i==3)
		{
			void saveDatabase(void);
		}
		else if (i==4)
		{
			void displayData(void);
		}
		else if (i==5)
		{
			void gradeStudent(void);
		}
		else if (i==6)
		{
			void displayAllData(void);
		}
		else if (i==7)
		{
			void findWinner(void);
		}
		else
		{
			void Quit(void);
		}
	}
	return 0;
}

}

/*
 * StudentRecord.cpp
 *
 *  Created on: 13 Mar 2014
 *      Author: grpjam001
 */

#include "StudentRecord.h"

#include <fstream>  // Needed for file stream objects
#include <iostream> // Needed for console stream objects
#include <sstream>  // Needed for string stream objects
#include <string>   // Needed for strings
#include <vector>   // Needed for the vector container

	//StudentRecord default constructor
	StudentRecord::StudentRecord(void)
	: Name("James"),Surname("Gripper"), StudentNumber("GRPJAM001"), ClassRecord("70 70 70 70")
	{}
	
	//StudentRecord constructor
	StudentRecord::StudentRecord(std::string n, std::string s, std::string num, std::string marks)
	: Name(n),Surname(s), StudentNumber(num), ClassRecord(marks)
	{}
		
	//copy constructor
	StudentRecord::StudentRecord(const StudentRecord& rhs):Name(rhs.Name), Surname(rhs.Surname),StudentNumber(rhs.StudentNumber),ClassRecord(rhs.ClassRecord)
	Name(rhs.Name),Surname(rhs.Surname), StudentNumber(rhs.StudentNumber), ClassRecord(rhs.ClassRecord)
	{}
	
	// Move Constructor
	StudentRecord::StudentRecord(const StudentRecord && rhs):Name(std::move(rhs.Name)), Surname(std::move(rhs.Surname)),StudentNumber(std::move(rhs.StudentNumber)),ClassRecord(std::move(rhs.ClassRecord))
	Name(rhs.Name),Surname(rhs.Surname), StudentNumber(rhs.StudentNumber), ClassRecord(rhs.ClassRecord)
	{}
	




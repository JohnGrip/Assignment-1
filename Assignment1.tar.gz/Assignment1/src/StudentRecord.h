/*
 * StudentRecord.h
 *
 *  Created on: 13 Mar 2014
 *      Author: grpjam001
 */

#ifndef STUDENTRECORD_H
#define STUDENTRECORD_H

#include <string>

class StudentRecord
{
public:
	std::string Name;
	std::string Surname;
	std::string StudentNumber;
	std::string ClassRecord;
	int token;

	StudentRecord(void);
	StudentRecord(std::string a, std::string b,std::string c, std::string d);
	StudentRecord(const StudentRecord & rhs);
	//StudentRecord(const StudentRecord && rhs);
};

#endif


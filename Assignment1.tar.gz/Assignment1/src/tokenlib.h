namespace tokenlib {

int acquire_token(void);
void release_token(int token);
void check_tokens(void);
void final_token_check(void);

}
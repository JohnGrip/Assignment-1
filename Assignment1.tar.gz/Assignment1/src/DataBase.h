/*
 * DataBase.h
 *
 *  Created on: 13 Mar 2014
 *      Author: grpjam001
 */
#include "StudentRecord.h"
#ifndef DATABASE_H
#define DATABASE_H

namespace GRPJAM001
{
class DataBase
{
public:
	void addStudent(StudentRecord sr);
	void deleteStudent(void);
	void readDatabase(void);
	void saveDatabase(void);
	void displayData(void);
	void gradeStudent(void);
	void displayAllData(void);
	void findWinner(void);
	void Quit(void);
};
}

#endif
